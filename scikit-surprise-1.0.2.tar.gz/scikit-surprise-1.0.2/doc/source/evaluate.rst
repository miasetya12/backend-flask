.. _evaluate:

evaluate module
===============

.. automodule:: surprise.evaluate
    :members:
    :exclude-members: CaseInsensitiveDefaultDict, CaseInsensitiveDefaultDictForBestResults
