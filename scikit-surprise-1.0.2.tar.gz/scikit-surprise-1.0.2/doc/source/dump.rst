.. _dump_module:

dump module
===============

.. automodule:: surprise.dump
    :members:
